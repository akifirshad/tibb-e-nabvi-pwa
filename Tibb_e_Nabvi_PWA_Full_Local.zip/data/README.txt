Tibb-e-Nabvi Natural Healing Dataset (Visual Edition)
---------------------------------------------------------
New fields added to each disease entry:
- remedy_image_url: URL to a single royalty-free image representing the remedy
- remedy_description: Short descriptive text (appearance, taste, texture) with a 'More images' link

Image sourcing:
- Primary source: Wikimedia Commons
- Secondary: Pixabay, Pexels (if needed)

License note:
- Images are from public/royalty-free repositories but please verify licenses if using commercially.
