Tibb-e-Nabvi PWA — Full Local Package
Open ui_pwa.html in a modern browser. This package contains the full dataset under /data.
